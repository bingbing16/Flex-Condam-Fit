@extends('layouts.frontend')

@section('content')
<div class="container-fluid p-5">
    <div class="mb-3 text-center">
        <h5 class="text-primary text-uppercase">Flex Condam Fit</h5>
        <h3 class="display-3 text-uppercase mb-0">"Push harder than yesterday if you want a different tomorrow"</h3>
    </div>

    <div class="container" style="display: flex; width: 1040px; justify-content: space-evenly; flex-wrap: wrap;">
        @forelse($exercises as $work)
            @if($work->category)
        <div class="card" style="margin: 10px; background-color: #fff; border-radius: 10px; box-shadow: 0 2px 20px rgba(0, 0, 0, 0.2); overflow: hidden; width: 300px;">
            <div class="card-header">
                @if($work->exerciseImages->count() > 0)
                    <img src="{{ asset($work->exerciseImages[0]->image) }}" alt="{{ $work->name}}" style="width: 100%; height: 200px; object-fit: cover;">
                @endif
            </div>
            <div class="card-body" style="display: flex; flex-direction: column; justify-content: center; align-items: flex-start; padding: 10px; min-height: 50px;">
                <span class="tag tag-teal" style="background: #cccccc; border-radius: 50px; font-size: 12px; margin: 0; color: #fff; padding: 2px 10px; text-transform: uppercase; cursor: pointer; background-color: #47bcd4;">{{ $work->category->description }}</span>
                    <h4  class="text-uppercase">
                        {{ $work->name }}
                    </h4>
                <p style="font-size: 20px; margin: 0 0 40px;">
                    Reps: {{ $work->description}}&emsp;
                    Sets: {{ $work->small_description}}
                </p>
            </div>
        </div>
        @else
            No Category Available
        @endif
        @empty
            No exercise Available
        @endforelse
    </div>
</div>


<!-- <div class="container-fluid p-5">
    <div class="mb-3 text-center">
        <h5 class="text-primary text-uppercase">Class Schedule</h5>
        <h1 class="display-3 text-uppercase mb-0">Exercise</h1>
    </div>
    <div class="tab-class text-center">
        <div class="tab-content">
            <div class="tab-pane fade show p-0 active">
                <div class="row g-5">
                @foreach($exercises as $work)
                    <div class="col-md-3 col-md-4 col-sm-6">
                        <a href="{{ url('workouts/'.$category->description) }}">
                        <div class="rowlo bg-dark rounded text-center py-5 px-3">
                            @if($work->exerciseImages->count() > 0)
                                <img src="{{ asset($work->exerciseImages[0]->image) }}" alt="{{ $work->name}}" class="position-absolute rounded" style="object-fit: cover; width: 300px; height:300px; margin-left:200px;">
                            @endif
                            <h6 class="text-uppercase text-light mb-3">6.00am - 8.00am</h6>
                            <h1 class="text-uppercase text-primary">hello</h1>
                            <p class="text-uppercase text-secondary mb-0" style="font-size: 11px;">Condam fit</p>
                        </div>
                        </a>
                    </div>
                @endforeach
                </div>
            </div>
             @forelse($exercises as $work)
                @if($work->category)
                <div class="container-fluid p-5">
                    <div class="row gx-5">
                        <div class="col-lg-5 mb-5 mb-lg-0" style="min-height: 500px;">
                            <div class="position-relative">
                            @if($work->exerciseImages->count() > 0)
                                <img src="{{ asset($work->exerciseImages[0]->image) }}" alt="{{ $work->name}}" class="position-absolute rounded" style="object-fit: cover; width: 300px; height:300px; margin-left:200px;">
                            @endif
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="mb-4" style="margin-top: 45px;">
                                <h4 class="text-uppercase">{{ $work->category->description }}</h4>
                                <h1 class="text-primary display-3 text-uppercase mb-0">{{ $work->name }}</h1>
                            </div>
                            <h3 class="text-uppercase mb-4">Reps: {{ $work->description}}</h3>
                            <h3 class="text-uppercase mb-4">Sets: {{ $work->small_description}}</h3>
                        </div>
                    </div>
                </div>
                @else
                    No Category Available
                @endif
            @empty
                No exercise Available
            @endforelse -->
        <!-- </div>
    </div>
</div> --> 

@endsection