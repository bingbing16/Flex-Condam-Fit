@extends('layouts.admin')

@section('content')

<div>
    <livewire:admin.calories.index/>
</div>
@endsection 