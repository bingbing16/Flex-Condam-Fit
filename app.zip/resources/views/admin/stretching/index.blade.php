@extends('layouts.admin')

@section('content')

<div>
    <livewire:admin.stretching.index/>
</div>

@endsection