@extends('layouts.admin')

@section('content')

<div>
    <livewire:admin.setting.index />
</div>

@endsection