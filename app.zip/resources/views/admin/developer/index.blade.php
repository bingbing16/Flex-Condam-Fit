@extends('layouts.admin')

@section('content')

<div>
    <livewire:admin.developer.index/>
</div>

@endsection