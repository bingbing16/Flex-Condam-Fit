@extends('layouts.admin')

@section('content')

<div>
    <livewire:admin.diet.index/>
</div>

@endsection