

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3>Exercises
                <a href="<?php echo e(url('exercises/create')); ?>" class="btn btn-primary btn-small float-end">Add Exercises</a>
                </h3>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <!-- <th>ID</th> -->
                            <th>Category</th>
                            <th>Name of Exercise</th>
                            <th>Day</th>
                            <th>Sets</th>
                            <th>Reps</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <!-- <td><?php echo e($exercise->id); ?></td> -->
                            <td>
                            <?php if($exercise->category): ?>
                                <?php echo e($exercise->category->name); ?>

                            <?php else: ?>
                                No Available Category
                            <?php endif; ?>
                            </td>
                            <td><?php echo e($exercise->name); ?></td>
                            <td>
                            <?php if($exercise->category): ?>
                                <?php echo e($exercise->category->description); ?>

                            <?php else: ?>
                                No Available Category
                            <?php endif; ?>
                            </td>
                            <td><?php echo e($exercise->small_description); ?></td>
                            <td><?php echo e($exercise->description); ?></td>
                            <td>
                                <?php if($exercise->exerciseImages): ?>
                                    <?php $__currentLoopData = $exercise->exerciseImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset($image->image)); ?>" style="width: 80px; height:80px;" class="me-4" alt="Image" />
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <h4>No Image</h4>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('exercises/'.$exercise->id.'/edit')); ?>" class="btn btn-sm btn-success">Edit</a>
                                <a href="<?php echo e(url('exercises/'.$exercise->id.'/delete')); ?>" onclick="return confirm('Delete this Exercise?')" class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7">No Exercises Available</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/admin/exercises/index.blade.php ENDPATH**/ ?>