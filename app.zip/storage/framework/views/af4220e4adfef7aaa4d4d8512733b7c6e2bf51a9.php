<div class="container-fluid bg-dark px-0">
        <div class="row gx-0">
            <div class="col-lg-3 bg-dark d-none d-lg-block">
                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $set): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('redirect')); ?>" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                    <img src="<?php echo e($set->logo); ?>" alt="logo" style="width: 120px; height:120px;">
                    <h1 class="text-primary text-uppercase" style="position: absolute;"><?php echo e($set->name); ?></h1>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-lg-9">
                <div class="row gx-0 bg-secondary d-none d-lg-flex">
                    <div class="col-lg-7 px-5 text-start">
                        <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                            <i class="fa fa-envelope text-primary me-2"></i>
                            <h6 class="mb-0">flexcondamfit@gmail.com</h6>
                        </div>
                        <div class="h-100 d-inline-flex align-items-center py-2">
                            <i class="fa fa-phone-alt text-primary me-2"></i>
                            <h6 class="mb-0">+63 953 220 4379</h6>
                        </div>
                    </div>
                    <div class="col-lg-5 px-5 text-end">
                        <div class="d-inline-flex align-items-center py-2">
                            <a class="btn btn-light btn-square rounded-circle me-2" href="">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a class="btn btn-light btn-square rounded-circle me-2" href="">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a class="btn btn-light btn-square rounded-circle me-2" href="">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a class="btn btn-light btn-square rounded-circle me-2" href="">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a class="btn btn-light btn-square rounded-circle" href="">
                                <i class="fab fa-youtube"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0 px-lg-5">
                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $set): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('redirect')); ?>" class="navbar-brand d-block d-lg-none">
                        <img src="<?php echo e($set->logo); ?>" alt="logo" style="width: 60px; height:60px; margin-left: 5px;">
                        <h1 class="m-0 display-4 text-primary text-uppercase"><?php echo e($set->name); ?></h1>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="<?php echo e(url('redirect')); ?>" class="nav-item nav-link">Home</a>
                            <a href="<?php echo e(url('about-us')); ?>" class="nav-item nav-link ">About Us</a>
                            <a href="<?php echo e(url('workouts')); ?>" class="nav-item nav-link">Workouts</a>
                            <a href="<?php echo e(url('stretchings')); ?>" class="nav-item nav-link">Stretching</a>
                            <!-- <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                                <div class="dropdown-menu rounded-0 m-0">
                                    <a href="blog.html" class="dropdown-item">Blog Grid</a>
                                    <a href="detail.html" class="dropdown-item">Blog Detail</a>
                                    <a href="testimonial.html" class="dropdown-item">Testimonial</a>
                                </div>
                            </div> -->
                            <a href="<?php echo e(url('food')); ?>" class="nav-item nav-link">Nutrition</a>
                        </div>
                            <li class="nav-item nav-profile dropdown" style="list-style-type: none;">
                            <a class="nav-link" id="profileDropdown" href="#" data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="nav-profile-text">
                                <?php if(Auth::user()->profile_photo_path): ?>
                                    <img class="h-8 w-8 rounded-full object-cover" src="/storage/<?php echo e(Auth::user()->profile_photo_path); ?>" alt="<?php echo e(Auth::user()->name); ?>" style="height:40px; width:40px; border-radius: 50%;"/>
                                <?php else: ?>
                                    <img class="h-8 w-8 rounded-full object-cover" src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="<?php echo e(Auth::user()->name); ?>" style="height:40px; width:40px; border-radius: 50%;" /> 
                                <?php endif; ?>
                                <p class="mb-1 text-black" style="display: inline; margin-left: 5px;"> <?php echo e(Auth::user()->name); ?></p>
                                </div>
                            </a>
                            <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                                <!-- Account Management -->
                                <a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>">
                                <i class="mdi mdi-cached me-2 text-success"></i><?php echo e(__('Profile')); ?>

                                </a>

                                <div class="border-t border-gray-100"></div>

                                <!-- Authentication -->
                                <form method="POST" id="logout-form" action="<?php echo e(route('logout')); ?>" x-data>
                                    <?php echo csrf_field(); ?>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    <i class="mdi mdi-logout me-2 text-primary"></i> <?php echo e(__('Logout')); ?>

                                    </a>
                                </form>
                            </div>
                            </li>
                        <!-- <div class="nav-profile-text">
                            <p class="mb-1 text-black"> <?php echo e(Auth::user()->name); ?></p>
                        </div> -->
                        <!-- <a href="#" class="btn btn-primary py-md-3 px-md-5 d-none d-lg-block">Join Us</a> -->
                    </div>
                </nav>
            </div>
        </div>
    </div>  <?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/layouts/inc/frontend/navbar.blade.php ENDPATH**/ ?>