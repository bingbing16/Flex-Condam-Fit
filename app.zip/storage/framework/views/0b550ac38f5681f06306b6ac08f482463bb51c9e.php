

<?php $__env->startSection('content'); ?>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700;800&display=swap');
  
  *, *:before, *:after {
    -moz-box-sizing: border-box;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
  }
  
  body {
    margin: 0;
  }
  
  .wk-desk-1{
    width: 8.333333%;
  }
  .wk-desk-2{
    width: 16.666667%;
  }
  .wk-desk-3{
    width: 25%;
  }
  .wk-desk-4{
    width: 33.333333%;
  }
  .wk-desk-5{
    width: 41.666667%;
  }
  .wk-desk-6{
    width: 50%;
  }
  .wk-desk-7{
    width: 58.333333%;
  }
  .wk-desk-8{
    width: 66.666667%;
  }
  .wk-desk-9{
    width: 75%;
  }
  .wk-desk-10{
    width: 83.333333%;
  }
  .wk-desk-11{
    width: 91.666667%;
  }
  .wk-desk-12{
    width: 100%;
  }
  
  @media (max-width: 1024px) {
    .wk-ipadp-1{
      width: 8.333333%;
    }
    .wk-ipadp-2{
      width: 16.666667%;
    }
    .wk-ipadp-3{
      width: 25%;
    }
    .wk-ipadp-4{
      width: 33.333333%;
    }
    .wk-ipadp-5{
      width: 41.666667%;
    }
    .wk-ipadp-6{
      width: 50%;
    }
    .wk-ipadp-7{
      width: 58.333333%;
    }
    .wk-ipadp-8{
      width: 66.666667%;
    }
    .wk-ipadp-9{
      width: 75%;
    }
    .wk-ipadp-10{
      width: 83.333333%;
    }
    .wk-ipadp-11{
      width: 91.666667%;
    }
    .wk-ipadp-12{
      width: 100%;
    }
  }
  
  @media (max-width: 768px) {
    .wk-tab-1{
      width: 8.333333%;
    }
    .wk-tab-2{
      width: 16.666667%;
    }
    .wk-tab-3{
      width: 25%;
    }
    .wk-tab-4{
      width: 33.333333%;
    }
    .wk-tab-5{
      width: 41.666667%;
    }
    .wk-tab-6{
      width: 50%;
    }
    .wk-tab-7{
      width: 58.333333%;
    }
    .wk-tab-8{
      width: 66.666667%;
    }
    .wk-tab-9{
      width: 75%;
    }
    .wk-tab-10{
      width: 83.333333%;
    }
    .wk-tab-11{
      width: 91.666667%;
    }
    .wk-tab-12{
      width: 100%;
    }
  }
  
  @media (max-width: 500px) {
    .wk-mobile-1{
      width: 8.333333%;
    }
    .wk-mobile-2{
      width: 16.666667%;
    }
    .wk-mobile-3{
      width: 25%;
    }
    .wk-mobile-4{
      width: 33.333333%;
    }
    .wk-mobile-5{
      width: 41.666667%;
    }
    .wk-mobile-6{
      width: 50%;
    }
    .wk-mobile-7{
      width: 58.333333%;
    }
    .wk-mobile-8{
      width: 66.666667%;
    }
    .wk-mobile-9{
      width: 75%;
    }
    .wk-mobile-10{
      width: 83.333333%;
    }
    .wk-mobile-11{
      width: 91.666667%;
    }
    .wk-mobile-12{
      width: 100%;
    }
  }
  
     *{
  font-family:Nunito, sans-serif;
}
.text-blk{
  margin-top:0px;
  margin-right:0px;
  margin-bottom:0px;
  margin-left:0px;
  line-height:25px;
}
.responsive-cell-block{
  min-height:75px;
}
.responsive-container-block{
  min-height:75px;
  height:fit-content;
  width:100%;
  display:flex;
  flex-wrap:wrap;
  margin-top:0px;
  margin-right:auto;
  margin-bottom:0px;
  margin-left:auto;
  justify-content:space-evenly;
}
.outer-container{
  padding-top:10px;
  padding-right:50px;
  padding-bottom:10px;
  padding-left:50px;
  background-color:rgb(244, 252, 255);
}
.inner-container{
  max-width:1320px;
  flex-direction:column;
  align-items:center;
  margin-top:50px;
  margin-right:auto;
  margin-bottom:50px;
  margin-left:auto;
}
.section-head-text{
  margin-top:0px;
  margin-right:0px;
  margin-bottom:5px;
  margin-left:0px;
  font-size:35px;
  font-weight:700;
  line-height:48px;
  color:rgb(0, 135, 177);
  margin:0 0 10px 0;
}
.section-subhead-text{
  font-size:25px;
  color:rgb(153, 153, 153);
  line-height:35px;
  max-width:470px;
  text-align:center;
  margin-top:0px;
  margin-right:0px;
  margin-bottom:60px;
  margin-left:0px;
}
.img-wrapper{
  width:100%;
}
.team-card{
  display:flex;
  flex-direction:column;
  align-items:center;
}
.social-media-links{
  width:125px;
  display:flex;
  justify-content:space-between;
}
.name{
  font-size:25px;
  font-weight:700;
  color:rgb(102, 102, 102);
  margin-top:10px;
  margin-right:0px;
  margin-bottom:5px;
  margin-left:0px;
}
.position{
  font-size:25px;
  font-weight:700;
  color:rgb(0, 135, 177);
  margin-top:0px;
  margin-right:0px;
  margin-bottom:30px;
  margin-left:0px;
}
.description{
font-size:15px;
  font-weight:700;
  margin-top:0px;
  margin-right:0px;
  margin-bottom:30px;
  margin-left:0px;
}
.team-img{
  width:250px;
  height:250px;
  border-radius: 50%;
}
.team-card-container{
  width:280px;
  margin:0 0 40px 0;
}
@media (max-width: 500px){
  .outer-container{
    padding:10px 20px 10px 20px;
  }
  .section-head-text{
    text-align:center;
  }
} 
</style>

<div class="responsive-container-block outer-container">
  <div class="responsive-container-block inner-container">
    <p class="text-blk section-head-text">Meet Our Team</p>
    <p class="text-blk section-subhead-text">In creating this successful website (BSIT-2A)</p>
    <div class="responsive-container-block">
        <?php $__currentLoopData = $developer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $developer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="responsive-cell-block wk-desk-3 wk-ipadp-3 wk-tab-6 wk-mobile-12 team-card-container">
                <div class="team-card">
                    <div class="img-wrapper">
                        <img src="<?php echo e($developer->image); ?>" class="team-img" />
                    </div>
                    <p class="text-blk name"><?php echo e($developer->name); ?></p>
                    <p class="text-blk position"><?php echo e($developer->position); ?></p>
                    <!-- <p class="text-blk description"><?php echo e($developer->description); ?></p> -->
                    <div class="social-media-links">
                        <a href="http://www.twitter.com/" target="_blank"><img
                            src="https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/gray-twitter.svg" /></a>
                        <a href="http://www.facebook.com/" target="_blank"><img
                            src="https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/gray-fb.svg" /></a>
                        <a href="http://www.instagram.com/" target="_blank"><img
                            src="https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/gray-insta.svg" /></a>
                        <a href="http://www.gmail.com/" target="_blank"><img
                            src="https://workik-widget-assets.s3.amazonaws.com/widget-assets/images/gray-mail.svg" /></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/frontend/developer.blade.php ENDPATH**/ ?>