

<?php $__env->startSection('content'); ?>

<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.diet.index', [])->html();
} elseif ($_instance->childHasBeenRendered('UXwrdDa')) {
    $componentId = $_instance->getRenderedChildComponentId('UXwrdDa');
    $componentTag = $_instance->getRenderedChildComponentTagName('UXwrdDa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UXwrdDa');
} else {
    $response = \Livewire\Livewire::mount('admin.diet.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('UXwrdDa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/admin/diet/index.blade.php ENDPATH**/ ?>