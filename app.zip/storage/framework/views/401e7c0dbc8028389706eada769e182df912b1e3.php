

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-5">
    <div class="mb-3 text-center">
        <h5 class="text-primary text-uppercase">Flex Condam Fit</h5>
        <h3 class="display-3 text-uppercase mb-0">"Push harder than yesterday if you want a different tomorrow"</h3>
    </div>

    <div class="container" style="display: flex; width: 1040px; justify-content: space-evenly; flex-wrap: wrap;">
        <?php $__empty_1 = true; $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($work->category): ?>
        <div class="card" style="margin: 10px; background-color: #fff; border-radius: 10px; box-shadow: 0 2px 20px rgba(0, 0, 0, 0.2); overflow: hidden; width: 300px;">
            <div class="card-header">
                <?php if($work->exerciseImages->count() > 0): ?>
                    <img src="<?php echo e(asset($work->exerciseImages[0]->image)); ?>" alt="<?php echo e($work->name); ?>" style="width: 100%; height: 200px; object-fit: cover;">
                <?php endif; ?>
            </div>
            <div class="card-body" style="display: flex; flex-direction: column; justify-content: center; align-items: flex-start; padding: 10px; min-height: 50px;">
                <span class="tag tag-teal" style="background: #cccccc; border-radius: 50px; font-size: 12px; margin: 0; color: #fff; padding: 2px 10px; text-transform: uppercase; cursor: pointer; background-color: #47bcd4;"><?php echo e($work->category->description); ?></span>
                    <h4  class="text-uppercase">
                        <?php echo e($work->name); ?>

                    </h4>
                <p style="font-size: 20px; margin: 0 0 40px;">
                    Reps: <?php echo e($work->description); ?>&emsp;
                    Sets: <?php echo e($work->small_description); ?>

                </p>
            </div>
        </div>
        <?php else: ?>
            No Category Available
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            No exercise Available
        <?php endif; ?>
    </div>
</div>


<!-- <div class="container-fluid p-5">
    <div class="mb-3 text-center">
        <h5 class="text-primary text-uppercase">Class Schedule</h5>
        <h1 class="display-3 text-uppercase mb-0">Exercise</h1>
    </div>
    <div class="tab-class text-center">
        <div class="tab-content">
            <div class="tab-pane fade show p-0 active">
                <div class="row g-5">
                <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-md-4 col-sm-6">
                        <a href="<?php echo e(url('workouts/'.$category->description)); ?>">
                        <div class="rowlo bg-dark rounded text-center py-5 px-3">
                            <?php if($work->exerciseImages->count() > 0): ?>
                                <img src="<?php echo e(asset($work->exerciseImages[0]->image)); ?>" alt="<?php echo e($work->name); ?>" class="position-absolute rounded" style="object-fit: cover; width: 300px; height:300px; margin-left:200px;">
                            <?php endif; ?>
                            <h6 class="text-uppercase text-light mb-3">6.00am - 8.00am</h6>
                            <h1 class="text-uppercase text-primary">hello</h1>
                            <p class="text-uppercase text-secondary mb-0" style="font-size: 11px;">Condam fit</p>
                        </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
             <?php $__empty_1 = true; $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($work->category): ?>
                <div class="container-fluid p-5">
                    <div class="row gx-5">
                        <div class="col-lg-5 mb-5 mb-lg-0" style="min-height: 500px;">
                            <div class="position-relative">
                            <?php if($work->exerciseImages->count() > 0): ?>
                                <img src="<?php echo e(asset($work->exerciseImages[0]->image)); ?>" alt="<?php echo e($work->name); ?>" class="position-absolute rounded" style="object-fit: cover; width: 300px; height:300px; margin-left:200px;">
                            <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="mb-4" style="margin-top: 45px;">
                                <h4 class="text-uppercase"><?php echo e($work->category->description); ?></h4>
                                <h1 class="text-primary display-3 text-uppercase mb-0"><?php echo e($work->name); ?></h1>
                            </div>
                            <h3 class="text-uppercase mb-4">Reps: <?php echo e($work->description); ?></h3>
                            <h3 class="text-uppercase mb-4">Sets: <?php echo e($work->small_description); ?></h3>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                    No Category Available
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                No exercise Available
            <?php endif; ?> -->
        <!-- </div>
    </div>
</div> --> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/frontend/workouts/index.blade.php ENDPATH**/ ?>