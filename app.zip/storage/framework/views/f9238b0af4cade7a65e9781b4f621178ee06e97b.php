

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3>Edit Exercises
                </h3>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('exercises/'.$exercise->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>  

                    <div class="row">
                        <div class="col-lg-12 mb-1">
                            <label>Category</label>
                            <select class="col-lg-12 mb-3" name="category_id" class="form-control">
                                <option value="" disabled>Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $exercise->category_id ? 'selected':''); ?> >
                                <?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label for="">Exercise Name</label>
                                <input type="text" class="form-control" name="name" value="<?php echo e($exercise->name); ?>" required autocomplete="name" autofocus>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="">Sets</label>
                                <textarea name="small_description" rows="1" class="form-control"><?php echo e($exercise->small_description); ?></textarea>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="">Reps</label>
                                <textarea name="description" rows="1" class="form-control"><?php echo e($exercise->description); ?></textarea>
                            </div>
                            <div class="col-md-12 mb-3">
                                <input type="file" multiple class="form-control" name="image[]">
                            </div>
                            <div>
                             <?php if($exercise->exerciseImages): ?>
                                <?php $__currentLoopData = $exercise->exerciseImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-2">
                                    <img src="<?php echo e(asset($image->image)); ?>" style="width: 80px; height:80px;" class="me-4 border" alt="Image" />
                                    <a href="<?php echo e(url('exercise-image/'.$image->id.'/delete')); ?>" class="d-block">Remove</a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <h4>No Image</h4>
                            <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary float-end">Update</button>
                            <a href="<?php echo e(url('exercises')); ?>" class="btn btn-danger float-end">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/admin/exercises/edit.blade.php ENDPATH**/ ?>