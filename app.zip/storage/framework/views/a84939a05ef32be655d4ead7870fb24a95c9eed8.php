<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3>Diet Plans
                    <a href="<?php echo e(url('nutrition/create')); ?>" class="btn btn-primary btn-small float-end">Add Diet Plans</a>
                </h3>
            </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        
                        <th>Day</th>
                        <th>Total Calories</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $diet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                       
                        <td><?php echo e($diets->name); ?></td>
                      
                        <td><?php echo e($diets->totalcalories); ?></td>
                        <td>
                            <img src="<?php echo e(asset($diets->image)); ?>" style="border-radius: 8px; width: 72px; height: 72px;" alt="Category Image">
                        </td>
                        <td>
                            <a href="<?php echo e(url('nutrition/'.$diets->id.'/edit')); ?>" class="btn btn-primary btn-small">Edit</a>
                            <a href="<?php echo e(url('nutrition/'.$diets->id.'/delete')); ?>"  onclick="return confirm('Delete this Exercise?')" class="btn btn-danger btn-small">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/livewire/admin/diet/index.blade.php ENDPATH**/ ?>