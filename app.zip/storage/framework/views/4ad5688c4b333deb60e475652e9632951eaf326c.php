

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3>Add Diet Plan
                    
                </h3>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('nutrition/add')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-12 mb-1">
                            <label>Calories</label>
                            <select class="col-lg-3 lg-7" name="category_id" class="form-control">
                                <?php $__currentLoopData = $calories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="">Day</label>
                            <input type="text" class="form-control" name="name" required autocomplete="name" autofocus>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="">Breakfast</label>
                            <textarea name="bfast" rows="7" class="form-control"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="">Lunch</label>
                            <textarea name="lunch" rows="7" class="form-control"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="">Snack</label>
                            <textarea name="snack" rows="7" class="form-control"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="">Dinner</label>
                            <textarea name="dinner" rows="7" class="form-control"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="">2nd Snack</label>
                            <textarea name="midsnack" rows="7" class="form-control"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="">Total Calories</label>
                            <input type="text" class="form-control" name="totalcalories" required autocomplete="totalcalories" autofocus>
                        </div>
                        <div class="col-md-12 mb-3">
                            <input type="file" class="form-control" name="image">
                        </div>
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-success btn-small float-end">Submit</button>
                            <a href="<?php echo e(url('nutrition')); ?>" class="btn btn-danger btn-small float-end">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/admin/diet/create.blade.php ENDPATH**/ ?>