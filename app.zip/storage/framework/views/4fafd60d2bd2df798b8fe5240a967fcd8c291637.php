<div>
    <div wire:ignore.self class="modal fade" id="deleteModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h1 class="modal-title fs-5" id="staticBackdropLabel">Delete title</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form wire:submit.prevent="destroyCategory">
            <div class="modal-body">
                <h6>Are you sure you want to delete this category?</h6>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary">Yes</button>
            </div>
        </form>
        </div>
    </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3>Calories Category
                    <a href="<?php echo e(url('nutrition-category/create')); ?>" class="btn btn-primary btn-small float-end">Add category</a>
                    </h3>
                </div>
                <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <!-- <th>ID</th> -->
                            <th>Name</th>
                            <th>Day</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $nutcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nutcast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- <td><?php echo e($nutcast->id); ?></td> -->
                            <td><?php echo e($nutcast->name); ?></td>
                            <td><?php echo e($nutcast->description); ?></td>
                            <td>
                                <img src="<?php echo e(asset($nutcast->image)); ?>" style="border-radius: 8px; width: 72px; height: 72px;" alt="Category Image">
                            </td>
                            <td>
                                <a href="<?php echo e(url('nutrition-category/'.$nutcast->id.'/edit')); ?>" class="btn btn-primary">Edit</a>
                                <a href="#" wire:click="deleteCategory(<?php echo e($nutcast->id); ?>)" data-bs-toggle="modal" data-bs-target="#deleteModal" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div>
                    <?php echo e($nutcat->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/livewire/admin/nut-cat/index.blade.php ENDPATH**/ ?>