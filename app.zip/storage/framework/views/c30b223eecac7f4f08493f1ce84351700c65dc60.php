

<?php $__env->startSection('content'); ?>

<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.setting.index', [])->html();
} elseif ($_instance->childHasBeenRendered('H1p9BoX')) {
    $componentId = $_instance->getRenderedChildComponentId('H1p9BoX');
    $componentTag = $_instance->getRenderedChildComponentTagName('H1p9BoX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('H1p9BoX');
} else {
    $response = \Livewire\Livewire::mount('admin.setting.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('H1p9BoX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/admin/setting/index.blade.php ENDPATH**/ ?>