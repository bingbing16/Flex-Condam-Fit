

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-5">
    <div class="text-center">
        <h5 class="text-primary text-uppercase">Flex Condam Fit</h5>
        <h3 class="display-3 text-uppercase mb-0">"Take care of your body. It’s the only place you have to live."</h3>
    </div>

    <div class="container" style="display: flex; width: 1040px; justify-content: space-evenly; flex-wrap: wrap;">
        <?php $__empty_1 = true; $__currentLoopData = $food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($work->category): ?>
        <div class="card">
            <div class="card-header">
                    <img src="<?php echo e(asset($work->image)); ?>" alt="<?php echo e($work->name); ?>" style="width: 100%; height: 200px; object-fit: cover;">
                
            </div>
            <div class="card-body" style="display: flex; flex-direction: column; justify-content: center; align-items: flex-start; padding: 10px; min-height: px;">
                <span class="tag tag-teal" style="background: #cccccc; border-radius: 50px; font-size: 12px; margin: 0; color: #fff; padding: 2px 10px; text-transform: uppercase; cursor: pointer; background-color: #47bcd4;"><?php echo e($work->category->description); ?></span>
                    <h3  class="text-uppercase">
                        <?php echo e($work->name); ?>

                    </h3>
                <h4><strong> Breakfast </strong></h4>
                <p style="font-size: 20px; margin: 0 0 40px;">
                    <?php echo e($work->bfast); ?>

                </p>
                <h4><strong> Snack </strong></h4>
                <p style="font-size: 20px; margin: 0 0 40px;">
                    <?php echo e($work->snack); ?>

                </p>
                <h4><strong> Lunch</strong></h4>
                <p style="font-size: 20px; margin: 0 0 40px;">
                    <?php echo e($work->lunch); ?>

                </p>
                <h4><strong> Snack</strong></h4>
                <p style="font-size: 20px; margin: 0 0 40px;">
                    <?php echo e($work->midsnack); ?>

                </p>
                <h4><strong> Dinner</strong></h4>
                <p style="font-size: 20px; margin: 0 0 40px;">
                    <?php echo e($work->dinner); ?>

                </p>
                <h4><strong> Total Calories</strong></h4>
                <p style="font-size: 20px; margin: 0 0 40px;">
                    <?php echo e($work->totalcalories); ?>

                </p>
            </div>
        </div>
        <?php else: ?>
            No Category Available
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            No exercise Available
        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/frontend/food/index.blade.php ENDPATH**/ ?>