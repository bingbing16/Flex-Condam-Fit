

<?php $__env->startSection('content'); ?>

<div class="container-fluid p-5">
    <div class="mb-5 text-center">
        <!-- <h5 class="text-primary text-uppercase">Nutrition</h5> -->
        <h1 class="display-3 text-uppercase mb-0">Nutrition Routine</h1>
    </div>
    <div class="tab-class text-center">
        <div class="tab-content">
            <div id="tab-1" class="tab-pane fade show p-0 active">
                <div class="row g-5">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-md-4 col-sm-6">
                            <a href="<?php echo e(url('food/'.$category->name)); ?>">
                                <div class="rowlo bg-dark rounded text-center py-5 px-3">
                                    <h6 class="text-uppercase text-light mb-3">calories</h6>
                                    <h1 class="text-uppercase text-primary"><?php echo e($category->name); ?></h1>
                                    <p class="text-uppercase text-secondary mb-0" style="font-size: 11px;">Flex Condam fit</p>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/frontend/food.blade.php ENDPATH**/ ?>