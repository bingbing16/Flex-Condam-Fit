<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3>Settings
                <!-- <a href="<?php echo e(url('setting/create')); ?>" class="btn btn-primary btn-small float-end">Add Settings</a> -->
                </h3>
            </div>
            <div class="card-body">
            <form action="<?php echo e(url('setting/add')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $set): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-3">
                    <label>System Name</label>
                    <input type="text" name="name" class="form-control" value ="<?php echo e($set->name); ?>">
                </div>
                <div class="mb-3">
                    <label>System Short Name</label>
                    <input type="text" name="short_name" class="form-control" value ="<?php echo e($set->short_name); ?>">
                </div>
                <div class="mb-3">
                    <label>Welcome Message</label>
                    <textarea name="welcome" rows="9" class="form-control"><?php echo e($set->welcome); ?></textarea>
                </div>
                <div class="mb-3">
                    <label>About Us</label>
                    <textarea name="about_us" rows="9" class="form-control"><?php echo e($set->about_us); ?></textarea>
                </div>
                <div class="col-md-12 mb-3">
                <label>Logo</label>
                    <input type="file" multiple class="form-control" name="logo">
                    <img src="<?php echo e(asset("$set->logo")); ?>" wdith="200px" height="200px" alt="Image" style="display: block;margin-left: auto; margin-right: auto;"/>
                </div>
                <div class="col-md-12 mb-3">
                <label>Cover</label>
                    <input type="file" multiple class="form-control" name="cover">
                    <img src="<?php echo e(asset("$set->cover")); ?>" wdith="200px" height="200px" alt="Image" style="display: block;margin-left: auto; margin-right: auto;"/>
                </div>
                <div class="col-md-12">
                    <!-- <button type="submit" class="btn btn-success float-end">Submit</button> -->
                    <a href="<?php echo e(url('setting/'.$set->id.'/edit')); ?>" class="btn btn-primary btn-small float-end">Edit</a> 
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/livewire/admin/setting/index.blade.php ENDPATH**/ ?>