

<?php $__env->startSection('content'); ?>

<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.developer.index', [])->html();
} elseif ($_instance->childHasBeenRendered('w6Qiah8')) {
    $componentId = $_instance->getRenderedChildComponentId('w6Qiah8');
    $componentTag = $_instance->getRenderedChildComponentTagName('w6Qiah8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('w6Qiah8');
} else {
    $response = \Livewire\Livewire::mount('admin.developer.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('w6Qiah8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/admin/developer/index.blade.php ENDPATH**/ ?>