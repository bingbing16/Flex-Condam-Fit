
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3>Stretching 
                <a href="<?php echo e(url('stretching/create')); ?>" class="btn btn-primary btn-small float-end">Add Stretching</a>
                </h3>
            </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <!-- <th>ID</th> -->
                                <th>Stretching Name</th>
                                <th>Sets</th>
                                <th>Reps</th>
                                <!-- <th>Stretching Description</th> -->
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $stretching; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stretchs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <!-- <td><?php echo e($stretchs->id); ?></td> -->
                                <td><?php echo e($stretchs->name); ?></td>
                                <td><?php echo e($stretchs->sets); ?></td>
                                <td><?php echo e($stretchs->reps); ?></td>
                                <!-- <td><?php echo e($stretchs->description); ?></td> -->
                                <td>
                                    <img src="<?php echo e(asset($stretchs->image)); ?>" style="border-radius: 8px; width: 72px; height: 72px;" alt="stretching Image">
                                </td>
                                <td>
                                    <a href="<?php echo e(url('stretching/'.$stretchs->id.'/edit')); ?>" class="btn btn-primary">Edit</a>
                                    <a href="<?php echo e(url('stretching/'.$stretchs->id.'/delete')); ?>"  onclick="return confirm('Delete this Stretching?')" class="btn btn-danger btn-small">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/livewire/admin/stretching/index.blade.php ENDPATH**/ ?>