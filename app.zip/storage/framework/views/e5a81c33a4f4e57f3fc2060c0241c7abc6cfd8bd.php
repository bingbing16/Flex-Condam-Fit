<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Flex Condam Fit</title>

        <!-- Scripts -->

        <!-- plugins:css -->
        <link rel="apple-touch-icon" sizes="180x180" href="/favicon/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon/favicon-16x16.png">
        <link rel="manifest" href="/favicon/site.webmanifest">
        <link rel="stylesheet" href="<?php echo e(asset('/admin/vendors/mdi/css/materialdesignicons.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/admin/vendors/css/vendor.bundle.base.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/admin/css/style.css')); ?>">

        <!-- Styles -->
        <?php echo \Livewire\Livewire::styles(); ?>

    </head>
    <body class="font-sans antialiased">

        <div class="container-scroller">
            <?php echo $__env->make('layouts.inc.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="container-fluid page-body-wrapper">
                <?php echo $__env->make('layouts.inc.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="main-panel">
                    <div class="content-wrapper">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>

            </div>
        </div>


        <?php echo $__env->yieldPushContent('modals'); ?>

        <script src="<?php echo e(asset('/admin/js/dashboard.js')); ?>"></script>
        <script src="<?php echo e(asset('/admin/vendors/js/vendor.bundle.base.js')); ?>"></script>
        <script src="<?php echo e(asset('/admin/js/misc.js')); ?>"></script>
        <script src="<?php echo e(asset('/admin/js/jquery.cookie.js')); ?>"></script>
        <script src="<?php echo e(asset('/admin/text/javascript')); ?>"></script>
        <script src="<?php echo e(asset('/admin/js/off-canvas.js')); ?>"></script>
        <script src="<?php echo e(asset('/admin/js/hoverable-collapse.js')); ?>"></script>
        <script src="<?php echo e(asset('/admin/js/todolist.js')); ?>"></script>

        <?php echo \Livewire\Livewire::scripts(); ?>

        <?php echo $__env->yieldPushContent('script'); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/layouts/admin.blade.php ENDPATH**/ ?>