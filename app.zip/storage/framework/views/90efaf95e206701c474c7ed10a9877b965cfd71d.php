<div>
    <div wire:ignore.self class="modal fade" id="delModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Category title</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form wire:submit.prevent="desCategory">
                    <div class="modal-body">
                        <h6>Are you sure you want to delete this data?</h6>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Yes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3>Calories Category
                    <a href="<?php echo e(url('nutrition-category/create')); ?>" class="btn btn-primary btn-small float-end">Add category</a>
                    </h3>
                </div>
                <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <!-- <th>ID</th> -->
                            <th>Calories</th>
                            <th>Description</th>
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $nutcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nutcast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- <td><?php echo e($nutcast->id); ?></td> -->
                            <td><?php echo e($nutcast->name); ?></td>
                            <td><?php echo e($nutcast->description); ?></td>
                            <td>
                                <img src="<?php echo e(asset($nutcast->image)); ?>" style="border-radius: 8px; width: 72px; height: 72px;" alt="Category Image">
                            </td>
                            <td>
                                <a href="<?php echo e(url('nutrition-category/'.$nutcast->id.'/edit')); ?>" class="btn btn-primary">Edit</a>
                                <a href="<?php echo e(url('nutrition-category/'.$nutcast->id.'/delete')); ?>" onclick="return confirm('Delete this Exercise?')" class="btn btn-danger">Delete</a>
                            </td>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div>
                    <?php echo e($nutcat->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('script'); ?>

    <script>
        window.addEventListener('close-modal', event => {

            $('#delModal').modal('hide');
        });
    </script>

<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/livewire/admin/calories/index.blade.php ENDPATH**/ ?>