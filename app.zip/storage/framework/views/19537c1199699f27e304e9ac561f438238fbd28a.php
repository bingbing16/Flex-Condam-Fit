
<?php if(session('message')): ?>
    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3>Developer
                <a href="<?php echo e(url('devs/create')); ?>" class="btn btn-primary btn-small float-end">Add Developer</a>
                </h3>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Position</th>
                            <!-- <th>Thougts</th> -->
                            <th>Image</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $developer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $developer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($developer->name); ?></td>
                            <td><?php echo e($developer->position); ?></td>
                            <!-- <td><?php echo e($developer->description); ?></td> -->
                            <td>
                                <img src="<?php echo e(asset($developer->image)); ?>" style="border-radius: 8px; width: 72px; height: 72px;" alt="Developer Image">
                            </td>
                            <td>
                                <a href="<?php echo e(url('devs/'.$developer->id.'/edit')); ?>" class="btn btn-primary">Edit</a>
                                <a href="<?php echo e(url('devs/'.$developer->id.'/delete')); ?>"  onclick="return confirm('Delete this Developer?')" class="btn btn-danger btn-small">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/livewire/admin/developer/index.blade.php ENDPATH**/ ?>