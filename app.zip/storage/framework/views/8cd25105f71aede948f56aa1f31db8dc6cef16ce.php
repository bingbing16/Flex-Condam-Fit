

<?php $__env->startSection('content'); ?>

<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.calories.index', [])->html();
} elseif ($_instance->childHasBeenRendered('UPBy2uZ')) {
    $componentId = $_instance->getRenderedChildComponentId('UPBy2uZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('UPBy2uZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UPBy2uZ');
} else {
    $response = \Livewire\Livewire::mount('admin.calories.index', []);
    $html = $response->html();
    $_instance->logRenderedChild('UPBy2uZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Fitapp\resources\views/admin/nutcat/index.blade.php ENDPATH**/ ?>