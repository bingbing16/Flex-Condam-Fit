<?php return array (
  'admin.calories.index' => 'App\\Http\\Livewire\\Admin\\Calories\\Index',
  'admin.category.index' => 'App\\Http\\Livewire\\Admin\\Category\\Index',
  'admin.developer.index' => 'App\\Http\\Livewire\\Admin\\Developer\\Index',
  'admin.diet.index' => 'App\\Http\\Livewire\\Admin\\Diet\\Index',
  'admin.nut-cat.index' => 'App\\Http\\Livewire\\Admin\\NutCat\\Index',
  'admin.setting.index' => 'App\\Http\\Livewire\\Admin\\Setting\\Index',
  'admin.stretching.index' => 'App\\Http\\Livewire\\Admin\\Stretching\\Index',
);